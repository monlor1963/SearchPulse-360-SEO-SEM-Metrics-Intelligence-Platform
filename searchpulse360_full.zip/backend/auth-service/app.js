
import express from 'express';
const app = express();
app.get('/', (req,res)=>res.json({service: 'OK'}));
app.listen(3000, ()=> console.log('service running'));
